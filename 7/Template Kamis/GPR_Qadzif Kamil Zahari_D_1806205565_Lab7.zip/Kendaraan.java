public class Kendaraan {
    private String nama;

	// Kendaraan constructor
    public Kendaraan(String nama) {
        this.nama = nama;
    }

	// return this kendaraan nama
    public String getNama() {
        return nama;
    }

	// return biaya for transport
    public int getBiaya(int jarak) {
        return 0;
    }

}